from django.apps import AppConfig


class MusicPlayerAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'music_player_app'
