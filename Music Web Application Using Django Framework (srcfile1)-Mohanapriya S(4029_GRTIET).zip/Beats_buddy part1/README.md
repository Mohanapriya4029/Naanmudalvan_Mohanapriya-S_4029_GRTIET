# Beads Buddy Using HTML CSS

Youtube Tutorial Link: https://youtu.be/TdjmTjuU8JE

Live Preview: https://constgenius.github.io/Beats_Buddy_HTML_CSS/

![Beads Buddy](images/Beads buddy.png)
